﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SkateBoard.Models
{
    public class CartItems
    {
        public Product Product { get; set; }
        public int qty { get; set; }
    }
   
}